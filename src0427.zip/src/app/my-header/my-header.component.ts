import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginUsers } from '../loginusers';
import { LoginserviceService } from '../services/loginservice.service';

@Component({
  selector: 'app-my-header',
  templateUrl: './my-header.component.html',
  styleUrls: ['./my-header.component.css']
})
export class MyHeaderComponent implements OnInit {
  aa = true;
  bb = false;
  cc = false;
  mydata: LoginUsers[];
  protected currentPrice: number;


  constructor(private router: Router, private loginserv: LoginserviceService ) {
    loginserv.loginEventer.subscribe(data => this.mydata = data);
   }

  ngOnInit() {
    this.loginserv.loginEventer.subscribe(data => this.mydata = data);

  }

  doClick() {
    this.router.navigate(['/page2']);
  }


  eventHandler(user: LoginUsers[]) {
    this.mydata = user;
  }
}
