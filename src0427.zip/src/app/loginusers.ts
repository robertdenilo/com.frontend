export class LoginUsers {
    id: string;
    name: string;
    item_id: string;
    form_id: string;
    status: string;
    type: string;
    modelID: string;
    role_status: string;
}
