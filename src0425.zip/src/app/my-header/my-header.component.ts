import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-header',
  templateUrl: './my-header.component.html',
  styleUrls: ['./my-header.component.css']
})
export class MyHeaderComponent implements OnInit {
  aa = true;
  bb = false;
  cc = false;

  constructor(private router: Router) { }

  ngOnInit() {
  }

  doClick() {
    this.router.navigate(['/page2']);
  }
}
